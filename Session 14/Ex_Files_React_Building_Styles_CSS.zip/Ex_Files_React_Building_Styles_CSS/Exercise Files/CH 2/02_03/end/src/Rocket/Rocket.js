import React from 'react';

export default class Rocket extends React.Component {
  render() {
    return (
      <div>
        <h1>Rocket</h1>
      </div>
    );
  }
}
