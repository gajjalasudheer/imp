import React, { Component } from 'react'
import './App.css'

class App extends Component {
  render() {
    return (
      <div>
        <a href="#home" />
        <img src="/img/is-an-image.jpg" alt="" />
      </div>
    )
  }
}

export default App
