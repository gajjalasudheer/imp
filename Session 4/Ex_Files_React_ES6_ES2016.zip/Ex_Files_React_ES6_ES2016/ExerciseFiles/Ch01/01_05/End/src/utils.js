const shakespeareApi = "https://api.graph.cool/simple/v1/shakespeare"

let options = {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    //we'll write this later
  })
}
