import React, {Component} from 'react';

//styles
import styles from './App.css';

class App extends Component {
  render() {
    return (
      <div className={styles.app}>
        <div className={styles.header}>
        </div>
      </div>
    )
  }
}

export default App;
