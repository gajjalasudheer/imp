import React from 'react';

export default class Grid extends React.Component {
  render() {
    return (
      <div>
        <h1>Grid</h1>
      </div>
    );
  }
}
