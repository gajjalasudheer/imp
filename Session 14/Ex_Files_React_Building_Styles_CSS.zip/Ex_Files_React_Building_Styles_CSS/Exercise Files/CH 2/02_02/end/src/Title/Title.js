import React from 'react';

const SingleCourse = (props) => {
  return (
    <div>
      <h1>Stateless component</h1>
    </div>
  );
}
