
// export default class MyComponent {
//   //some stuff
// }
//
//
// export default function() {
//   //get the data
// }
//
//
//
// export default const mySetup = {      //DOESNT WORK
//   environment: 'tropical'
// }
//
//
//
//
// const mySetup = {
//   environment: 'tropical'
// }
//
//
// export default mySetup
//
//
//
//
//
// export const widget = { /* ... */}
//
// export function birthdayReminder () {
//   /* ... */
//   return 'Happy Birthday!'
// }
//
// let trees = []
//
// class ShinyButton extends Component {
//  render() {
//    return (
//      //...
//    )
//  }
// }
//
// export {trees, ShinyButton}
