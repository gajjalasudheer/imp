export const AUTH_CONFIG = {
  domain: 'mannydesigns.auth0.com',
  clientId: '9woV8xlfwyh3YfRCOcc9j9p5T3N6Jl4X',
  callbackUrl: 'http://localhost:3000/callback',
  apiUrl: 'https://manny-linkedin'
}
