export function functionArgs () {

  // function getEmAll(...args) {
  //   console.log(args)
  // }
  //
  // function setSomeDefaults(myString = "", aList = []) {
  //   console.log(myString, aList)
  // }
  //
  //
  // function configurationThing({monsterSize, boatCapacity}) {
  //   console.log(monsterSize, boatCapacity)
  // }

}
