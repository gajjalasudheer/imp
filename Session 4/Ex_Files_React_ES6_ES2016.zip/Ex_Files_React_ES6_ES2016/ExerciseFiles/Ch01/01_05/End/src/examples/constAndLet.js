export function constAndLet() {

    // iceCream = "salted caramel"
    // console.log("hoisted?", iceCream)
    //
    // var iceCream = "chocolate"
    // console.log("declared", iceCream)

  //   iceCream = "strawberry"
  //   console.log("reassigned?", iceCream)
  //
  //   var iceCream = "vanilla"
  //   console.log("redeclared?", iceCream)
  //
  //
    // gelato = "mango"
    // console.log("hoisted?", gelato)
    //
    // const gelato = "lemon"
    // console.log("declared", gelato)

  //   gelato = "mint"
  //   console.log("reassigned", gelato)
  //
  //   const gelato = "almond"
  //   console.log("redeclared", gelato )
  //
  //
    // froYo = "brownie"
    // console.log("hoisted?", froYo)
    //
    // let froYo = "cherry"
    // console.log("declared", froYo)
    //
  //   froYo = "cheese cake"
  //   console.log("reassigned", froYo)
  //
  //   let froYo = "passion fruit"
  //   console.log("redeclared", froYo )
  //
  //

  // const canIChangeThis = "What is this variable?"
  // console.log(canIchangeThis)
  //
  // canIChangeThis = "Did I change this?"
  // console.log(canIChangeThis)

  // const toppings = ["sprinkles", "strawberries"]
  //
  // toppings.push("fudge")
  //
  //
  // console.log(toppings)

  // ["sprinkles", "strawberries", "fudge"]
  //
  // Object.freeze(toppings)
  //
  // toppings.push('raisins')

}
