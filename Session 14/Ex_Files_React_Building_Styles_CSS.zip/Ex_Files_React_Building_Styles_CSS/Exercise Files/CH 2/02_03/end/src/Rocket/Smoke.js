import React from 'react';

export default class Smoke extends React.Component {
  render() {
    return (
      <div>
        <h1>Smoke</h1>
      </div>
    );
  }
}
