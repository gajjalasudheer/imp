import React from 'react';

export default class Background extends React.Component {
  render() {
    return (
      <div>
        <h1>Background</h1>
      </div>
    );
  }
}
