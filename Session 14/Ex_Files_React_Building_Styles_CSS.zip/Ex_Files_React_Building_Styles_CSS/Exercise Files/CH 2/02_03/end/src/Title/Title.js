import React from 'react';

const Title = () => {
  return (
    <div>
      <h1>Title</h1>
    </div>
  );
}

export default Title;
